#!/bin/sh
#
rm -r /usr/script-a

wget -O /tmp/script-a.tar.gz "https://drive.google.com/uc?id=1YEeCZwgH9AkPzdnoQR95SGak6jK7cggU&export=download"

tar -xzf /tmp/*.tar.gz -C /

rm -r /tmp/script-a.tar.gz

killall -9 enigma2

sleep 2;

exit 0
