#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/scripts/-/raw/main/remove/_remove-sats-channels-lists.sh -O - | /bin/sh 

exit 0