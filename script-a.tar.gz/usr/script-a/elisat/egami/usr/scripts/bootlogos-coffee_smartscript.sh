#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/display/-/raw/main/house/bootlogos-house.sh -O - | /bin/sh 

exit 0