#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/settings/-/raw/main/tuner/tuner.sh -O - | /bin/sh 

exit 0