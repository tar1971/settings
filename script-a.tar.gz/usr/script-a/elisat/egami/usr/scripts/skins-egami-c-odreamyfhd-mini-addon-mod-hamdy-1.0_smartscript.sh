#!/bin/sh
if grep -qs -i "egami" /etc/image-version; then
wget -q "--no-check-certificate" https://gitlab.com/eliesat/skins/-/raw/main/egami/c-odreamyfhd-mini/c-odreamyfhd-mini-addon.sh -O - | /bin/sh 
else 
echo "> install egami image & try again ..."
######################################
fi
exit 0