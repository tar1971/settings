#!/bin/sh
if grep -qs -i "openpli" /etc/issue; then
wget -q "--no-check-certificate" https://gitlab.com/eliesat/skins/-/raw/main/pli/multiposter-1.6.sh -O - | /bin/sh 
else 
echo "> install openpli image & try again ..."
######################################
fi
exit 0