#!/bin/sh

opkg install --force-overwrite https://oottppxx.github.io/enigma2/latest/quarterpounder-latest.ipk

exit 0







