#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/extensions/-/raw/main/servicescanupdates/servicescanupdates.sh -O - | /bin/sh 

exit 0