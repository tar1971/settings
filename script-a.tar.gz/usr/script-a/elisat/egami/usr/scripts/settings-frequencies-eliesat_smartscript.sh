#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/settings/-/raw/main/eliesat/installer.sh -O - | /bin/sh 

exit 0