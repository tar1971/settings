#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/softcams/-/raw/main/audi06_19/oscam.sh -O - | /bin/sh 

exit 0