#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/display/-/raw/main/christmas/bootlogos-christmas.sh -O - | /bin/sh 

exit 0