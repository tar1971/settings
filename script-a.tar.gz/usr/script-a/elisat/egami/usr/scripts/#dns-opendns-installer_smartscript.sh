#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/scripts/-/raw/main/all/_dns-opendns-installer.sh -O - | /bin/sh 

exit 0