#!/bin/sh
if grep -qs -i "OpenSPA" /etc/image-version; then
wget -q "--no-check-certificate" https://gitlab.com/eliesat/skins/-/raw/main/all/premium-fhd/premium-fhd.sh -O - | /bin/sh 
else 
echo "> install openspa image & try again ..."
######################################
fi
exit 0

