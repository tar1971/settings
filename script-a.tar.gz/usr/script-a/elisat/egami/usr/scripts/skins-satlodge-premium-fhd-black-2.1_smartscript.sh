#!/bin/sh
if grep -qs -i "satlodge" /etc/issue; then
wget -q "--no-check-certificate" https://gitlab.com/eliesat/skins/-/raw/main/all/premium-fhd/premium-fhd-black.sh -O - | /bin/sh 
else 
echo "> install satlodge image & try again ..."
######################################
fi
exit 0

