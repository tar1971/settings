#!/bin/sh
if grep -qs -i "openvix" /etc/image-version; then
wget -q "--no-check-certificate" https://gitlab.com/eliesat/skins/-/raw/main/openvix/youvix-px-mod-hamdy.sh -O - | /bin/sh 
else 
echo "> install openvix image & try again ..."
######################################
fi
exit 0