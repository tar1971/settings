#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/softcams/-/raw/main/mohamed-os/gosatplus-oscam-.sh -O - | /bin/sh 

exit 0