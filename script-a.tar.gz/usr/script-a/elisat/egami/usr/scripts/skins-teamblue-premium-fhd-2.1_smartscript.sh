#!/bin/sh
if grep -qs -i "teamBlue" /etc/image-version; then
wget -q "--no-check-certificate" https://gitlab.com/eliesat/skins/-/raw/main/all/premium-fhd/premium-fhd.sh -O - | /bin/sh 
else 
echo "> install teamblue image & try again ..."
######################################
fi
exit 0

