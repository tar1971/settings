#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/display/-/raw/main/radiologo/radiologo-4.sh -O - | /bin/sh 

exit 0