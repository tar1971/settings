#!/bin/sh
if grep -qs -i "PURE2" /etc/image-version; then
wget -q "--no-check-certificate" https://gitlab.com/eliesat/skins/-/raw/main/all/premium-fhd/premium-fhd-blue.sh -O - | /bin/sh 
else 
echo "> install pure2 image & try again ..."
######################################
fi
exit 0

