#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/extensions/-/raw/main/ncam-status/ncam-status.sh -O - | /bin/sh 

exit 0