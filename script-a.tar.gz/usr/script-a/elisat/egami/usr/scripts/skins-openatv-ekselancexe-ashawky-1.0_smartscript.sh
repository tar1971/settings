#!/bin/sh
if grep -qs -i "openATV" /etc/image-version; then
wget -q "--no-check-certificate" https://gitlab.com/eliesat/skins/-/raw/main/atv/ekselancexe-ashawky.sh?inline=false -O - | /bin/sh 
else 
echo "> install openatv image & try again ..."
######################################
fi
exit 0