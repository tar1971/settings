#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/display/-/raw/main/spinner/spinner-clock-2.sh -O - | /bin/sh 

exit 0
