#!/bin/sh
if grep -qs -i "egami" /etc/image-version; then
wget -q "--no-check-certificate" https://gitlab.com/eliesat/skins/-/raw/main/all/novaler/novaler-s-x-blue.sh -O - | /bin/sh 
else 
echo "> install egami image & try again ..."
######################################
fi
exit 0