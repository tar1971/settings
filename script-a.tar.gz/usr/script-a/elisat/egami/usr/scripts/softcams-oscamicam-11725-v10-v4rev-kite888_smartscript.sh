#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/softcams/-/raw/main/kite888/oscamicam.sh -O - | /bin/sh 

exit 0