#!/bin/sh
if [ -r /usr/lib/enigma2/python/OPENDROID ]; then
wget -q "--no-check-certificate" https://gitlab.com/eliesat/skins/-/raw/main/all/premium-fhd/premium-fhd-blue.sh -O - | /bin/sh 
else 
echo "> install opendroid image & try again ..."
######################################
fi
exit 0

