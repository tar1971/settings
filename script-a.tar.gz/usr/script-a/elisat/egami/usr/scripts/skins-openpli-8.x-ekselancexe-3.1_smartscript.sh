#!/bin/sh
if grep -qs -i "openpli" /etc/issue; then
wget -q "--no-check-certificate" https://gitlab.com/eliesat/skins/-/raw/main/pli/ekselancexe-3.1.sh -O - | /bin/sh 
else 
echo "> install openpli image & try again ..."
######################################
fi
exit 0