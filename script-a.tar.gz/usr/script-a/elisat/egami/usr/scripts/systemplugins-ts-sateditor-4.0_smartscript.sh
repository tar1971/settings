#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/extensions/-/raw/main/ts-sateditor/ts-sateditor.sh -O - | /bin/sh 

exit 0