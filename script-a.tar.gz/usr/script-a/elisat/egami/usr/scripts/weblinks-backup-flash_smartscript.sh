wget https://raw.githubusercontent.com/fairbird/backupflash/main/installer.sh -qO - | /bin/sh






           
