#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/softcams/-/raw/main/raed/ncam.sh -O - | /bin/sh 

exit 0