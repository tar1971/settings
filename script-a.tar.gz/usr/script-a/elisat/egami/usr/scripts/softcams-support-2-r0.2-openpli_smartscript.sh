#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/softcams/-/raw/main/support/support-2-r0.2.sh -O - | /bin/sh 

exit 0