#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/display/-/raw/main/spinner/spinner-hdglass17-1.sh -O - | /bin/sh 

exit 0
