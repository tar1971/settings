#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/softcams/-/raw/main/linuxsat25/oscam.sh -O - | /bin/sh 

exit 0