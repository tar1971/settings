#!/bin/sh

wget https://raw.githubusercontent.com/e2TURK/omb-enhanced/main/install.sh -qO - | /bin/sh

exit 0





























