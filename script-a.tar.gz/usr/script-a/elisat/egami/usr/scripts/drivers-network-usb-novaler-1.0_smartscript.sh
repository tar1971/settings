#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/drivers/-/raw/main/network-usb-novaler-1.0.sh -O - | /bin/sh 

exit 0