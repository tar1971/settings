wget https://raw.githubusercontent.com/sivel/speedtest-cli/master/speedtest.py -qO - | python







           
