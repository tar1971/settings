#!/bin/sh
if grep -qs -i "openATV" /etc/image-version; then
wget -q "--no-check-certificate" https://gitlab.com/eliesat/skins/-/raw/main/all/pal-a.shawky/pal.ashawky.sh -O - | /bin/sh 
else 
echo "> install openatv image & try again ..."
######################################
fi
exit 0