#!/bin/sh
if grep -qs -i "egami" /etc/image-version; then
wget -q "--no-check-certificate" https://gitlab.com/eliesat/skins/-/raw/main/all/jihad/jihad-1.0.sh -O - | /bin/sh 
else 
echo "> install egami image & try again ..."
######################################
fi
exit 0