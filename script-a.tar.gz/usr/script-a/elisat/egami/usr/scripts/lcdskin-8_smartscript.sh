#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/display/-/raw/main/lcdskin/lcdskin-8.sh -O - | /bin/sh 

exit 0