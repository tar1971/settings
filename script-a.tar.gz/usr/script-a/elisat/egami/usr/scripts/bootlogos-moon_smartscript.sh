#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/display/-/raw/main/moon/bootlogos-moon.sh -O - | /bin/sh 

exit 0