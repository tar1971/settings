#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/display/-/raw/main/lcdskin/lcdskin-11.sh -O - | /bin/sh 

exit 0