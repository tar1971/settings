#!/bin/sh
if grep -qs -i "openbh" /etc/image-version; then
wget -q "--no-check-certificate" https://gitlab.com/eliesat/skins/-/raw/main/all/premium-fhd/premium-fhd.sh -O - | /bin/sh 
else 
echo "> install obh image & try again ..."
######################################
fi
exit 0

