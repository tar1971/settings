#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/scripts/-/raw/main/all/_fix-hdd--space-inodes.sh -O - | /bin/sh 

exit 0
