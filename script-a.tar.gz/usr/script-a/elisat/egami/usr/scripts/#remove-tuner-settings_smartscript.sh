#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/scripts/-/raw/main/remove/_remove-tuner-settings.sh -O - | /bin/sh 

exit 0