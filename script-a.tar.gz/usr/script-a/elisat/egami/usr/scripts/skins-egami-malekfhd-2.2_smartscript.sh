#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/skins/-/raw/main/egami/malek/malek-fhd.sh?inline=false -O - | /bin/sh 

exit 0