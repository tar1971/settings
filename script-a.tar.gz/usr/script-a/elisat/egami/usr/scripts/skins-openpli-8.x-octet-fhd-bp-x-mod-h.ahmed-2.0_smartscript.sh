#!/bin/sh
if grep -qs -i "openpli" /etc/issue; then
wget -q "--no-check-certificate" https://gitlab.com/eliesat/skins/-/raw/main/pli/octet-fhd-bp-x-mod-h.ahmed-2.0.sh -O - | /bin/sh 
else 
echo "> install openpli image & try again ..."
######################################
fi
exit 0