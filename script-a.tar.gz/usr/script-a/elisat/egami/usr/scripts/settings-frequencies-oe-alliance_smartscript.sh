#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/settings/-/raw/main/oe-alliance/installer.sh -O - | /bin/sh 

exit 0