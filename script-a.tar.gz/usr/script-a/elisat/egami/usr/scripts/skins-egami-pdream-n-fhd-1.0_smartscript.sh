#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/skins/-/raw/main/egami/pdreamy/pdreamy-n-fhd.sh -O - | /bin/sh 

exit 0