#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/extensions/-/raw/main/plutotv/plutotv.sh -O - | /bin/sh 

exit 0