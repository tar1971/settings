echo
#!/bin/sh
#

rm -f /etc/defaultsat.tar.gz && rm -f /etc/enigma2/lamedb && rm -f /etc/enigma2/*.tv && rm -f /etc/enigma2/*.radio && rm -f /etc/enigma2/*.del && rm -f /etc/enigma2/*.sh && wait

wget  -O /tmp/channel-goda.tar.gz "https://onedrive.live.com/download?cid=CFCA224FBA296C58&resid=CFCA224FBA296C58%21181&authkey=AMKwKmuSyuNTUUw"

tar -xzf /tmp/*.tar.gz -C /


wait

killall -9 enigma2

sleep 2;

exit 0
