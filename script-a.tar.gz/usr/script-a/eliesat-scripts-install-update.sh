#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/scripts/-/raw/main/eliesat-scripts.sh -O - | /bin/sh 

exit 0
