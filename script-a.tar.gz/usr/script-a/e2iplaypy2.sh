opkg remove --force-depends enigma2-plugin-extensions-IPTVPlayer

wait
#!/bin/sh
#

wget -O /tmp/e2iplayer-py2.tar.gz "https://raw.githubusercontent.com/tarekzoka/e2iplayer-py3/main/e2iplayer-py2.tar.gz"

tar -xzf /tmp/*.tar.gz -C /

rm -r /tmp/e2iplayer-py2.tar.gz

echo "         UPLOADED BY TARK_HANFY    "


killall -9 enigma2

sleep 2;




