
#!/bin/sh
#

wget https://raw.githubusercontent.com/tarekzoka/SKINS/main/installer9.sh -O - | /bin/sh
