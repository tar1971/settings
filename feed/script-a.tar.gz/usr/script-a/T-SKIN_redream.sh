opkg install --force-overwrite https://drive.google.com/uc?id=1Hz4fydUClhj3xw2BJ8h7E9jDGvsV5dL_&export=download
wait
sleep 2;
exit 0







