rm -r /media/hdd/epg.dat /media/usp/epg.dat
wait
rm -r /etc/enigma2/epg.dat 
echo ""
exit 0
