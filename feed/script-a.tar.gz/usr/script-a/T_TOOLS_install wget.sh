opkg update
opkg install wget

