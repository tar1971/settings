echo

opkg update && opkg upgrade && opkg install gstreamer1.0-plugins-good gstreamer1.0-plugins-base
gstreamer1.0-plugins-bad-meta
 gstreamer1.0-plugins-bad gstreamer1.0-plugins-ugly
libgstplayer-1.0-0 opkg install --force-depends gstreamer1.0-plugins-bad-meta

wait

opkg update && opkg install gstreamer1.0-plugins-good


wait

wget -O /tmp/ipaudio-6.A.tar.gz "https://raw.githubusercontent.com/tarekzoka/ipaudio/main/ipaudio-6.6.tar.gz"

tar -xzf ipaudio-6.A.tar.gz  -C /

wait

rm -f /tmp/ipaudio-6.6.tar.gz

wait

wget -O /etc/asound.conf "https://drive.google.com/uc?id=11O8PtGM4Bi3N3LuW3I7udH34sjmu2wyV&export=download"


echo "   UPLOADED BY  >>>>   TAREK_TT "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0

###################################
#                                 #
#           BY-TAREK-HANFY        #              
#                                 #
###################################


