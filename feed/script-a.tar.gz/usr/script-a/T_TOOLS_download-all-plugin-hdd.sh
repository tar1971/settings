
#!/bin/sh
#
mkdir /hdd/download


wget -O /media/hdd/download/fullbackup_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/backup/enigma2-plugin-extensions-automatic-fullbackup_6.8_all.ipk"
wait
wget -O /media/hdd/download/bootlogokids_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/bootlogos/enigma2-plugin-extensions-bootlogo-kids-stony272_01_all.ipk"
wait
wget -O /media/hdd/download/clearmem_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/other/enigma2-plugin-extensions-clearmem-lite_1.0_all.ipk"
wait
wget -O /media/hdd/download/e2m3ubouquet_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/bouquets/enigma2-plugin-extensions-e2m3u2bouquet_1.0.43_all.ipk"
wait
wget -O /media/hdd/download/freeserver_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/multimedia/enigma2-plugin-extensions-freeserver_7.2.6_all.ipk"
wait
wget -O /media/hdd/download/jediepgxtream_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/epg/enigma2-plugin-extensions-jediepgxtream_2.03.20210412_all.ipk"
wait
wget -O /media/hdd/download/openmultiboot2.6_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/multiboot/enigma2-plugin-extensions-openmultiboot_2.6_all.ipk"
wait
wget -O /media/hdd/download/subsupport1.56_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/multimedia/enigma2-plugin-extensions-subssupport_1.5.6-r55_mips32el.ipk"
wait
wget -O /media/hdd/download/subsupport1.58_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/multimedia/enigma2-plugin-extensions-subssupport_1.5.8-r0_all.ipk"
wait
wget -O /media/hdd/download/tspanel_01_all.ipk "http://178.63.156.75/paneladdons/panels/enigma2-plugin-extensions-tspanel_8.1_all.ipk"
wait
wget -O /media/hdd/download/tvtom3u_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/multimedia/enigma2-plugin-extensions-tvtom3upanel_1.4_all.ipk"
wait
wget -O /media/hdd/download/xcpluginforever_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/multimedia/enigma2-plugin-extensions-xcplugin-forever_1.7_all.ipk"
wait
wget -O /media/hdd/download/xstreamity_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/multimedia/enigma2-plugin-extensions-xstreamity_3.53.20211113_all.ipk"
wait
wget -O /media/hdd/download/xtraevent_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/multimedia/enigma2-plugin-extensions-xtraevent_v2.0_all.ipk"
wait
wget -O /media/hdd/download/youtube_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/multimedia/enigma2-plugin-extensions-youtube_h1+git874+4961980-r0.0_all.ipk"
wait
wget -O /media/hdd/download/satvenus_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/cam/enigma2-plugin-extensions-satvenus-panel_7.3.2_all.ipk"
wait
wget -O /media/hdd/download/ncam_01_all.ipk "http://178.63.156.75/paneladdons/Ncam/Unofficial/NCam12.3/enigma2-plugin-softcams-ncam_V12.3-r1_all.ipk"
wait
wget -O /media/hdd/download/oscam_01_all.ipk "http://178.63.156.75/paneladdons/OSCamEmus/11703/enigma2-softcams-oscam-all-images_11.703-emu-r798-arm+mips_all.ipk"
wait
wget -O /media/hdd/download/levi45multicam_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/cam/enigma2-plugin-extensions-levi45multicammanager_8.2_all.ipk"
wait
wget -O /media/hdd/download/raedquicksignal_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/other/enigma2-plugin-extensions-raedquicksignal_7.4-r0_all.ipk"
wait
wget -O /media/hdd/download/e2iplayer_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/multimedia/enigma2-plugin-extensions-e2iplayer_15.11.2021_all.ipk"
wait
wget -O /media/hdd/download/freearhey_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/multimedia/enigma2-plugin-extensions-freearhey_2.5_all.ipk"
wait
wget -O /media/hdd/download/jedimakerxtream_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/multimedia/enigma2-plugin-extensions-jedimakerxtream_6.20.20210928_all.ipk"
wait
wget -O /media/hdd/download/cccam_01_all.ipk "http://178.63.156.75/paneladdons/CCcamEmu/2.3.9/enigma2-softcams-cccam-all-images_2.3.9-r2-RAED_OE2.0_all.ipk"
wait
wget -O /media/hdd/download/cfgzoom_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/multimedia/cfg_Zoom_Final_FIX7d_all.ipk"
wait
wget -O /media/hdd/download/torrent_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/multimedia/enigma2-plugin-extensions-torrentplayer_2.1_f020920201_all.ipk"
wait
wget -O /media/hdd/download/historyzap_py3_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/other/enigma2-historyzapselector_v3.2-PY3_all.ipk"
wait
wget -O /media/hdd/download/bootlogo_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/bootlogos/enigma2-plugin-extensions-bootlogo-mika22_0.3_all.ipk"
wait
wget -O /media/hdd/download/openwebifvti_01_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/other/enigma2-plugin-extensions-openwebif_1.4.9-git20210930-r4_vti.ipk"
wait
wget -O /media/hdd/download/ajpanel_01_all.ipk "http://178.63.156.75/paneladdons/panels/enigma2-plugin-extensions-ajpanel_v3.1.0_all.ipk"
wait
wget -O /media/hdd/download/oscamrevcam_01_all.ipk "http://178.63.156.75/paneladdons/OSCamEmus/11703/enigma2-plugin-softcams-oscam-revcamV2_11.703-emu-r798_all.ipk"
wait
wget -O /media/hdd/download/oscamsupcam_01_all.ipk "http://178.63.156.75/paneladdons/OSCamEmus/11703/enigma2-plugin-softcams-oscam-supcam_11.703-emu-r798_all.ipk"
wait
wget -O /media/hdd/download/ncamrevcam_01_all.ipk "http://178.63.156.75/paneladdons/Ncam/Unofficial/NCam12.4/enigma2-plugin-softcams-ncam-revcam_12.4_all.ipk"
wait
wget -O /media/hdd/download/ncamsupcam_01_all.ipk "http://178.63.156.75/paneladdons/Ncam/Unofficial/NCam12.4/enigma
2-plugin-softcams-ncam-supcam_12.4_all.ipk"
wait
wget -O /media/hdd/download/extensions-xtraevent-py3_4.4_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/multimedia/enigma2-plugin-extensions-xtraevent-py3_4.4_all.ipk"
wait
wget -O /media/hdd/download/xtraevent_v5.2_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/multimedia/enigma2-plugin-extensions-xtraevent_v5.2_all.ipk"
wait
wget -O /media/hdd/download/feeds-finder_-V1.6-OE2_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/other/feeds-finder_20201016-V1.6-momi133-OE2_all.ipk"
wait
wget -O /media/hdd/download/ipaudio_1.6_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/other/enigma2-plugin-extensions-ipaudio_1.6_all.ipk"
wait
wget -O /media/hdd/download/footonsat_1.6.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/sport/enigma2-plugin-extensions-footonsat_1.6.ipk"
wait
wget -O /media/hdd/download/livefootball_8.5_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/sport/enigma2-plugin-extensions-livefootball_8.5_all.ipk"
wait
wget -O /media/hdd/download/picon-buddy_0.0.2-Beta_all.ipk "http://178.63.156.75/paneladdons/Pluginsoe20/picon/enigma2-plugin-extensions-picon-buddy_0.0.2-Beta_all.ipk"
wait

sleep 2;


































