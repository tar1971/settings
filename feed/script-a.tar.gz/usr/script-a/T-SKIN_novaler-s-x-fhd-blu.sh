
echo
opkg install --force-overwrite  "https://drive.google.com/uc?id=1jIK5eqvRLTCmrHF_cv1p5oEeqFCHMkoV&export=download"
wait
sleep 2;
exit 0


