echo
opkg install --force-overwrite  https://github.com/tarekzoka/plugins/blob/main/bootlogoswapper_v2.0_all.ipk?raw=true
wait
sleep 2;
exit 0

