echo

wget "https://raw.githubusercontent.com/tarekzoka/SKINS/main/fullhdglass17_7.10_all.deb.tar.gz"


tar -xzf fullhdglass17_7.10_all.deb.tar.gz  -C /

wait
rm -f /tmp/fullhdglass17_7.10_all.deb.tar.gz
echo "   UPLOADED BY  >>>>   TAREK_TT "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0















