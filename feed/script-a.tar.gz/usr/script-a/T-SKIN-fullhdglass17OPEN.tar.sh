echo


wget "https://raw.githubusercontent.com/tarekzoka/SKINS/main/fullhdglass17_2.33.tar.gz"


tar -xzf fullhdglass17_2.33.tar.gz  -C /

wait
rm -f /tmp/fullhdglass17_2.33.tar.gz
echo "   UPLOADED BY  >>>>   TAREK_TT "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0














