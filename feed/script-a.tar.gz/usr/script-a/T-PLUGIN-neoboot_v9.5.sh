echo
opkg install --force-overwrite  https://github.com/tarekzoka/65/blob/master/enigma2-plugin-extensions-neoboot_v9.58-r3-reboot_all.ipk?raw=true
wait
sleep 2;
exit 0






















