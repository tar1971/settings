echo
wget http://tunisia-dreambox.info/TSplugins/NewVirtualKeyBoard/installer.sh -O - | /bin/sh
wait
sleep 2;
exit 0


