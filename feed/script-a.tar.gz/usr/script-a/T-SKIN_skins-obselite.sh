echo
opkg install --force-overwrite  https://github.com/tarekzoka/SKINS/blob/main/enigma2-plugin-skins-obselite-fhd-all_1.0_all.ipk?raw=true

wait

killall -9 enigma2

sleep 2;
