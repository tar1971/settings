echo
wget http://files.getras.co/rev-openpli-arm.sh -O - | /bin/sh
























