echo
opkg install --force-overwrite  https://drive.google.com/uc?id=1wL0aiY2lwANHf2cIDs2xOZHyspvXBerQ&export=download
wait
sleep 2;
exit 0
