wait

wget "https://raw.githubusercontent.com/tarekzoka/SKINS/main/cinogri-pli-fhd-vs-poster.tar.gz"

tar -xzf cinogri-pli-fhd-vs-poster.tar.gz  -C /

wait

rm -f /tmp/cinogri-pli-fhd-vs-poster.tar.gz

echo "   UPLOADED BY  >>>>   TAREK_TT "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0

