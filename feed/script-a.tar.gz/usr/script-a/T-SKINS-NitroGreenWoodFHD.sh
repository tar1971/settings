wait


wget "https://raw.githubusercontent.com/tarekzoka/SKINS/main/NitroGreen.tar.gz"


tar -xzf NitroGreen.tar.gz  -C /

wait
rm -f /tmp/NitroGreen.tar.gz
echo "   UPLOADED BY  >>>>   TAREK_TT "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0
