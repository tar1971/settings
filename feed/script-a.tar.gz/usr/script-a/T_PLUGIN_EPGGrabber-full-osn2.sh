echo
#!/bin/sh

#

wget -O /tmp/EPGGrabber.tar.gz "https://raw.githubusercontent.com/tarekzoka/plugins/main/EPGGrabber.tar.gz"

tar -xzf /tmp/*.tar.gz -C /

rm -r /tmp/EPGGrabber.tar.gz

wait

#!/bin/sh

echo 1 > /proc/sys/vm/drop_caches
echo 2 > /proc/sys/vm/drop_caches
echo 3 > /proc/sys/vm/drop_caches


python /usr/lib/enigma2/python/Plugins/Extensions/EPGGrabber/providers/beinConnect.py
wait 
python /usr/lib/enigma2/python/Plugins/Extensions/EPGGrabber/providers/elcin.py
wait 
python /usr/lib/enigma2/python/Plugins/Extensions/EPGGrabber/providers/bein.py
wait 
python /usr/lib/enigma2/python/Plugins/Extensions/EPGGrabber/providers/satTvB.py
wait
python /usr/lib/enigma2/python/Plugins/Extensions/EPGGrabber/providers/osnplay.py
wait
python /usr/lib/enigma2/python/Plugins/Extensions/EPGGrabber/providers/beinent.py
wait
python /usr/lib/enigma2/python/Plugins/Extensions/EPGGrabber/providers/jawwyOS.py
wait
python /usr/lib/enigma2/python/Plugins/Extensions/EPGGrabber/providers/beincin.py

wait

#!/bin/sh

#

wget -O /tmp/plugin-PAY.tar.gz "https://drive.google.com/uc?id=1pobekBL2pkWbZjS6G4K-WYaGOElIQO1a&export=download"

tar -xzf /tmp/*.tar.gz -C /

rm -r /tmp/plugin-PAY.tar.gz

wait

killall -9 enigma2

sleep 2;

exit 0


###################################
#                                 #
#           BY-TAREK-HANFY        #              
#                                 #
###################################

