
opkg install gstplayer
wait
sleep 2;
exit 0
