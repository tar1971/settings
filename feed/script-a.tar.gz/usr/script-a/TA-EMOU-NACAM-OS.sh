echo
wget https://raw.githubusercontent.com/tarekzoka/oscam-nacam/main/nacam-os.sh -O - | /bin/sh
