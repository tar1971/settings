echo
#!/bin/sh
#

wget -O /etc/enigma2/ipaudio.json "https://drive.google.com/uc?id=1kzRDN4AWTHlDtfRr1NhYonzMNocwxxKF&export=download"

wait


     ************************************************
     *                                               *
      *             By TAREK-HANFY                    *
       *                                               *
        *                                               *
         *************************************************




killall -9 enigma2

exit 0













