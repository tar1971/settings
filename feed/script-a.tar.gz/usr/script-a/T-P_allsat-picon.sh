echo

opkg install --force-overwrite  https://drive.google.com/uc?id=1m2XC4aA2iO4BjWvjV2OVT09VIkVzlAQ7&export=download
wait
sleep 2;
exit 0






