echo
#!/bin/sh
#

wget https://raw.githubusercontent.com/tarekzoka/65/main/tarek.sh -O - | /bin/sh
