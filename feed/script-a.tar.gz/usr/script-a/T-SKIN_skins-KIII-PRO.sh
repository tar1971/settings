echo
opkg install --force-overwrite  https://github.com/tarekzoka/65/blob/master/enigma2-plugin-skins-KIII-PRO-by-zelda77_v3.3_all.ipk?raw=true
wait
sleep 2;
exit 0
