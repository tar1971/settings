echo
wget -O /etc/enigma2/epg.dat "https://drive.google.com/uc?id=1B2oWkCEahLcekd7oxi4PgF1ciwsMFBW2&export=download"
wait
wget -O /media/hdd/epg.dat "https://drive.google.com/uc?id=1B2oWkCEahLcekd7oxi4PgF1ciwsMFBW2&export=download"

killall -9 enigma2

sleep 2;

exit 0

























