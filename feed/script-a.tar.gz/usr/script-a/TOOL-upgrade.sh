echo
opkg update
reboot
wait
sleep 2;
exit 0
