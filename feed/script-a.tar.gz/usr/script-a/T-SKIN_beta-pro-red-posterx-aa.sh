echo
#!/bin/sh
#

wget -O /tmp/Beta_Pro_FHDred.tar.gz "https://raw.githubusercontent.com/tarekzoka/SKINS/main/beta-pro/Beta_Pro_FHDred.tar.gz"

tar -xzf /tmp/*.tar.gz -C /

rm -r /tmp/Beta_Pro_FHDred.tar.gz

killall -9 enigma2

sleep 2;

exit 0
