#!/bin/sh
 # 
 wget https://raw.githubusercontent.com/tarekzoka/SKINS/main/bo.sh -O - | /bin/sh

















