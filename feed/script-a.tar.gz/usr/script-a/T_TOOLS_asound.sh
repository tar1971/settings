#!/bin/sh
#

wget -O /etc/asound.conf "https://drive.google.com/uc?id=11O8PtGM4Bi3N3LuW3I7udH34sjmu2wyV&export=download"

exit 0




