echo
#!/bin/sh
echo
wget -O /etc/enigma2/MyMetrixLiteBackup.dat "https://onedrive.live.com/?id=root&cid=CFCA224FBA296C58&qt=sharedby#export=download"
exit 0
