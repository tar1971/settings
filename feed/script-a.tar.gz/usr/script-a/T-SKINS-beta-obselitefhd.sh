echo
wget https://raw.githubusercontent.com/tarekzoka/SKINS/main/beta.sh -O - | /bin/sh
