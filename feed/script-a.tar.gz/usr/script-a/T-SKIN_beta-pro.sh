echo
#!/bin/sh
#

wget -O /tmp/skin-beta-pro-Xtraevent.tar.gz "https://drive.google.com/uc?id=1izYyjtOsS-WWex9vkghNy0bWzFrCK5ld&export=download"

tar -xzf /tmp/*.tar.gz -C /


wait

killall -9 enigma2

sleep 2;

exit 0
