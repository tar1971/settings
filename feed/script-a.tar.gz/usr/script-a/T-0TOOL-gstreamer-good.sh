echo
opkg update && opkg upgrade && opkg install gstreamer1.0-plugins-good gstreamer1.0-plugins-base
gstreamer1.0-plugins-bad-meta
 gstreamer1.0-plugins-bad gstreamer1.0-plugins-ugly
libgstplayer-1.0-0 opkg install --force-depends gstreamer1.0-plugins-bad-meta




