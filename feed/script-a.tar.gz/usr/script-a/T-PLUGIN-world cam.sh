echo
#!/bin/sh
#

wget -O /var/volatile/tmp/worldcam_4.2_r5_all.ipk "https://github.com/tarekzoka/65/blob/master/enigma2-plugin-extensions-worldcam_4.2_r5_all.ipk?raw=true"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/worldcam_4.2_r5_all.ipk
wait
sleep 2;
exit 0




