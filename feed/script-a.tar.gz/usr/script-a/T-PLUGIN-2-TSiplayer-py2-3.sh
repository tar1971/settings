echo
#!/bin/sh
#

wget -q "--no-check-certificate" http://ipkinstall.ath.cx/ipk-install/E2IPLAYER-DREAMSATPANEL/e2iplayer.sh -O - | /bin/sh
