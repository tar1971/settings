echo
opkg install --force-overwrite  https://github.com/tarekzoka/oscam-nacam/blob/main/enigma2-plugin-softcams-oscam_11.711-emu-r798_all.ipk?raw=true
wait
sleep 2;
exit 0
