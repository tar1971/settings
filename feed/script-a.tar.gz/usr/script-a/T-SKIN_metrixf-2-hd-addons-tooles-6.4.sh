echo
#!/bin/sh
#

wget -O /tmp/metrixfhd2-addons.tar.gz "https://raw.githubusercontent.com/tarekzoka/plugins/main/metrixfhd2-addons.tar.gz"

tar -xzf /tmp/*.tar.gz -C /

rm -r /tmp/metrixfhd2-addons.tar.gz

killall -9 enigma2

sleep 2;

exit 0

