
#!/bin/sh
#

wget https://raw.githubusercontent.com/tarekzoka/SKINS/main/installer3.sh -O - | /bin/sh